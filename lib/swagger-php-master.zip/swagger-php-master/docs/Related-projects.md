# Related projects


Project | Description | URL
--- | --- | ---
[silex2swagger](https://github.com/DerManoMann/silex2swagger) | Generate swagger documentation from Silex Annotations | https://packagist.org/packages/radebatz/silex2swagger

Don't see a swagger-php related project listed? Create a pull request.