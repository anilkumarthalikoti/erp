<?php
namespace SwaggerFixures;

/**
 * @SWG\Definition
 */
trait Hello
{

    /**
     * @SWG\Property()
     */
    public $greet = 'Hello!';
}
