<?php
namespace SwaggerFixtures;

class ParentWithoutDocBlocks extends GrandParent
{
    public $firstname;
}
