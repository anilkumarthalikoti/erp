<?php
namespace SwaggerFixtures;

/**
 * An intermediate class
 */
class Parent extends GrandParent
{

    /**
     * Without swagger annotations
     */
    public $firstname;
}
