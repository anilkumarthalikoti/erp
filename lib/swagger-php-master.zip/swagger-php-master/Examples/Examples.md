## petstore.swagger.io

Using swagger-php to generate the [example for swagger-ui](http://petstore.swagger.io/)

## swagger-spec

Using swagger-php to generate the [examples in the spec](https://github.com/swagger-api/swagger-spec/tree/master/examples/v2.0/json)

## petstore
The smallest example, contains only 1 operation.

## petstore-simple
An example with 4 operations on 2 paths.

## petstore-with-external-docs
Very similar to petstore-simple but with externalDocs